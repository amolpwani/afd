package com.ford.afd.service;

import com.ford.afd.model.MasterDataDataItem;
import com.ford.afd.repository.MasterDataItemRepository;
import com.ford.afd.service.MasterDataItemService;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.runners.MockitoJUnitRunner;
import java.util.ArrayList;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class MasterDataItemServiceTest {

	@InjectMocks
	private MasterDataItemService masterDataItemService;

	@Mock
	private MasterDataItemRepository masterDataItemRepositoryMock;

	@Test
	public void allMasterDataItem_shouldReturnEmptyWhenNoListDataFound() {
		//Arrange
		when(masterDataItemRepositoryMock.findAll()).thenReturn(Lists.emptyList());
		//Act
		List<MasterDataDataItem> actualResult = masterDataItemService.allMasterDataItems();
		//Assert
		assertThat(actualResult).hasSize(0);
	}

	@Test
	public void allMasterDataItem_shouldReturnValuesWhenListDataFound() {
		//Arrange
		List<MasterDataDataItem> masterDataDataItem = new ArrayList<>(1);
		masterDataDataItem.add(buildMasterDataItem());
		when(masterDataItemRepositoryMock.findAll()).thenReturn(masterDataDataItem);
		//Act
		List<MasterDataDataItem> actualResult = masterDataItemService.allMasterDataItems();
		//Assert
		assertThat(actualResult).isEqualTo(masterDataDataItem);
	}

	@Test
	public void saveMasterDataItem_shouldSaveAListData() {
		//Arrange
		ArgumentCaptor<MasterDataDataItem> masterDataItemCaptor = ArgumentCaptor.forClass(MasterDataDataItem.class);
		when(masterDataItemRepositoryMock.save(masterDataItemCaptor.capture()))
		.thenReturn(buildMasterDataItem());
		//Act
		masterDataItemService.saveMasterDataItem(buildMasterDataItem());

		MasterDataDataItem expectedEntity = buildMasterDataItem();
		expectedEntity.setId(1);
		//Assert
		assertThat(masterDataItemCaptor.getValue()).isEqualToComparingFieldByField(expectedEntity);
	}

	@Test
	public void deleteListDataById_shouldInvokeDeleteOnRepository() {
		//Arrange
		ArgumentCaptor<MasterDataDataItem> masterDataItemCaptor = ArgumentCaptor.forClass(MasterDataDataItem.class);
		doNothing().when(masterDataItemRepositoryMock).delete(masterDataItemCaptor.capture());
		//Act
		masterDataItemService.deleteMasterDataItem(buildMasterDataItem());
		//Assert
		assertThat(masterDataItemCaptor.equals(masterDataItemCaptor));
	}

	@Test
	public void allMasterDataItem_shouldRetrieveAllListData() {
		//Arrange
		List<MasterDataDataItem> masterDataDataItems = new ArrayList<>(1);
		masterDataDataItems.add(buildMasterDataItem());
		when(masterDataItemRepositoryMock.findAll()).thenReturn(masterDataDataItems);
		//Act
		List<MasterDataDataItem> actualMasterDataItems = masterDataItemService.allMasterDataItems();
		//Assert
		assertThat(actualMasterDataItems).isNotNull();
		assertThat(actualMasterDataItems).hasSize(1);
		assertThat(actualMasterDataItems.get(0).getDescription()).isEqualTo("TestingBusiness");
	}

	private MasterDataDataItem buildMasterDataItem() {
		MasterDataDataItem entity = new MasterDataDataItem("BU1", "TestingBusiness", true, 1 );
		entity.setId(1);
		return entity;
	}
}