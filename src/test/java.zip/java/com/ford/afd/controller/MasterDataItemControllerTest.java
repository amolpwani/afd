package com.ford.afd.controller;

import static org.assertj.core.api.Assertions.assertThat;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.ford.afd.model.MasterDataDataItem;
import com.ford.afd.service.MasterDataItemService;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class MasterDataItemControllerTest {

	@LocalServerPort
	private int port = 8080;

	private URL base;

	@Autowired
	private TestRestTemplate template;

	@Autowired
	private MasterDataItemService masterDataItemService;

	private List<Long> testEntitiesId = new ArrayList<>();

	@Before
	public void setUp() throws Exception {
		MasterDataDataItem listDataItem1 = masterDataItemService.saveMasterDataItem(buildListDataItem("BU1", "description 1", 100));
		MasterDataDataItem listDataItem2 = masterDataItemService.saveMasterDataItem(buildListDataItem("BU2", "description 2", 100));
		testEntitiesId.add(listDataItem1.getId());
		testEntitiesId.add(listDataItem2.getId());
		this.base = new URL("http://localhost:" + port);
	}

	@After
	public void tearDown() {
		for (Long listDataId : testEntitiesId) {
			masterDataItemService.deleteMasterDataItem(masterDataItemService.findMasterDataItemById(listDataId));
		}
	}

	private MasterDataDataItem buildListDataItem(String code, String description, long listId) {
		return new MasterDataDataItem(code, description, true, listId);
	}

	@Test
	public void shouldRetrieveOneListDataItem() throws Exception {
		//Act
		ParameterizedTypeReference<MasterDataDataItem> returnType = new ParameterizedTypeReference<MasterDataDataItem>() {
		};
		ResponseEntity<MasterDataDataItem> actualResponse =  template.exchange(
				base.toString() + "/masterdataitem/getMasterDataItem/" + testEntitiesId.get(0),
				HttpMethod.GET,
				null,
				returnType);

		//Assert
		assertThat(actualResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
		MasterDataDataItem expectedListData = new MasterDataDataItem("BU1", "description 1", true, 100);

		expectedListData.setId(testEntitiesId.get(0));
		assertThat(actualResponse.getBody()).isEqualToComparingFieldByField(expectedListData);
	}

	@Test
	public void shouldRetrieveAllListData() {
		//Act
		ParameterizedTypeReference<List<MasterDataDataItem>> returnType = new ParameterizedTypeReference<List<MasterDataDataItem>>() {
		};

		ResponseEntity<List<MasterDataDataItem>> actualResponse =  template.exchange(
				base.toString() + "/masterdataitem/getMasterDataItem",
				HttpMethod.GET,
				null,
				returnType);
		//Assert
		assertThat(actualResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void shouldUpdateListData() throws Exception {
		//Act
		ParameterizedTypeReference<MasterDataDataItem> returnType = new ParameterizedTypeReference<MasterDataDataItem>() {
		};

		MasterDataDataItem updateListDataItem = new MasterDataDataItem("BU2", "updated description 1", false, 100);
		updateListDataItem.setId(testEntitiesId.get(0));

		ResponseEntity<MasterDataDataItem> actualResponse =  template.exchange(
				base.toString() + "/masterdataitem/getMasterDataItem/" + testEntitiesId.get(0),
				HttpMethod.PUT,
				new HttpEntity<MasterDataDataItem>(updateListDataItem, new HttpHeaders()),
				MasterDataDataItem.class,
				returnType);

		//Assert
		MasterDataDataItem actualBody = actualResponse.getBody();
		assertThat(actualResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
		MasterDataDataItem expectedListData = new MasterDataDataItem("BU2", "updated description 1", false, 100);
		expectedListData.setId(testEntitiesId.get(0));
		assertThat(actualResponse.getBody()).isEqualToComparingFieldByField(expectedListData);
		assertThat(masterDataItemService.findMasterDataItemById(actualBody.getId())).isEqualToComparingFieldByField(expectedListData);
	}

	@Test
	public void shouldDeleteListById() {
		//Act
		ParameterizedTypeReference<List<MasterDataDataItem>> returnType = new ParameterizedTypeReference<List<MasterDataDataItem>>() {
		};

		template.delete(
				base.toString() + "/masterdataitem/getMasterDataItem/"+ testEntitiesId.get(0));

		testEntitiesId.remove(testEntitiesId.get(0));

		ResponseEntity<List<MasterDataDataItem>> actualResponse =  template.exchange(
				base.toString() + "/masterdataitem/getMasterDataItem",
				HttpMethod.GET,
				null,
				returnType);

		//Assert
		assertThat(actualResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
	}

	@Test
	public void shouldCreateListData() throws Exception {
		//Act
		ParameterizedTypeReference<MasterDataDataItem> returnType = new ParameterizedTypeReference<MasterDataDataItem>() {
		};

		MasterDataDataItem createListData = new MasterDataDataItem("BU3", "description 3", false, 100);

		ResponseEntity<MasterDataDataItem> actualResponse =  template.exchange(
				base.toString() + "/masterdataitem/getMasterDataItem",
				HttpMethod.POST,
				new HttpEntity<MasterDataDataItem>(createListData, new HttpHeaders()),
				MasterDataDataItem.class,
				returnType);

		//Assert
		MasterDataDataItem actualBody = actualResponse.getBody();
		testEntitiesId.add(actualBody.getId());
		assertThat(actualResponse.getStatusCode()).isEqualTo(HttpStatus.OK);
		MasterDataDataItem expectedListData = new MasterDataDataItem("BU3", "description 3", false, 100);
		expectedListData.setId(actualBody.getId());
		assertThat(actualBody).isEqualToComparingFieldByField(expectedListData);
		assertThat(masterDataItemService.findMasterDataItemById(actualBody.getId())).isEqualToComparingFieldByField(expectedListData);
	}
}